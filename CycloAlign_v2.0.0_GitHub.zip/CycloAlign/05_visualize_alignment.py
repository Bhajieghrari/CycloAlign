#!/usr/bin/env python3
"""
05_visualize_alignment.py — Dot map and score-profile visualization of CP
detection results.

Addresses: Reviewer 1 suggested revision 5 ("Dot maps of sequences are a good
diagnostic, as discussed in Uliel et al 1999. Line graph of the scores on the
bottom row, showing the ... best scoring breakpoint is also helpful") and
suggested revision 3 (visualization of the best scoring alignment).

Outputs (PNG, 200 dpi):
  dotmap.png       — residue-identity dot map of X (rows) vs Y* = Y+Y (columns);
                     a genuine CP appears as two anti-diagonal streaks whose
                     join marks the breakpoint
  score_profile.png— bottom-row scores F(n, j) for j in [m, 2m]; the best
                     endpoint (max) and the implied breakpoint are annotated
  alignment.txt    — the traceback alignment strings with the breakpoint

Usage
-----
python 05_visualize_alignment.py --seq1 X.fasta --seq2 Y.fasta --matrix BLOSUM45
python 05_visualize_alignment.py --demo
"""

from __future__ import annotations

import argparse
import os

import numpy as np

from cycloalign_core import AA, CyclicSemiglobalAligner, clean


def dotmap(x: str, yy: str, out: str = "dotmap.png", window: int = 1):
    """Simple identity dot map (optionally windowed)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    a = np.array([ord(c) for c in x], dtype=np.int16)
    b = np.array([ord(c) for c in yy], dtype=np.int16)
    if window > 1:
        a = np.convolve(a, np.ones(window) / window, mode="valid")
        b = np.convolve(b, np.ones(window) / window, mode="valid")
    img = (a[:, None] == b[None, :])

    m = len(yy) // 2
    fig, ax = plt.subplots(figsize=(7, 4.5), constrained_layout=True)
    ax.imshow(img, aspect="auto", cmap="Greys", interpolation="nearest", origin="upper")
    ax.axvline(m - 0.5, color="#B23A48", lw=1.2, ls="--", label="duplication boundary (j = m)")
    ax.set_xlabel("Y* = Y + Y (residue index)")
    ax.set_ylabel("X (residue index)")
    ax.set_title("Dot map: X vs duplicated target Y*")
    ax.legend(loc="upper right", fontsize=8)
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print(f"Wrote {out}")


def score_profile(aln: CyclicSemiglobalAligner, m: int, out: str = "score_profile.png"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    prof = aln.last_profile
    if prof is None:
        raise RuntimeError("run align() first")
    js = np.arange(m, len(prof))
    vals = prof[m:]
    best_j = js[int(np.argmax(vals))]

    fig, ax = plt.subplots(figsize=(7, 3.8), constrained_layout=True)
    ax.plot(js, vals, lw=1.4, color="#2C5F8A")
    ax.axvline(best_j, color="#B23A48", lw=1.2, ls="--",
               label=f"best endpoint j = {best_j}")
    ax.axvline(best_j - m, color="#3A7D44", lw=1.2, ls=":",
               label=f"implied breakpoint q = {best_j - m}")
    ax.set_xlabel("column j in Y* (second copy)")
    ax.set_ylabel("bottom-row score F(n, j)")
    ax.set_title("Score profile on the bottom row")
    ax.legend(fontsize=8)
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print(f"Wrote {out}")
    return int(best_j - m)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seq1", help="FASTA file or raw sequence, query X")
    ap.add_argument("--seq2", help="FASTA file or raw sequence, target Y")
    ap.add_argument("--matrix", default="BLOSUM45")
    ap.add_argument("--window", type=int, default=1, help="dot map window size")
    ap.add_argument("--outdir", default=".")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.demo or not (args.seq1 and args.seq2):
        import random
        rng = random.Random(5)
        dom1 = "".join(rng.choice(AA) for _ in range(110))
        dom2 = "".join(rng.choice(AA) for _ in range(110))
        x = "".join(rng.choice(AA) if rng.random() < 0.08 else c for c in (dom1 + dom2))
        y = "".join(rng.choice(AA) if rng.random() < 0.08 else c for c in (dom2 + dom1))
        note = "(demo sequences: 220 aa permuted pair at ~90% identity)"
    else:
        def read_input(s):
            if os.path.exists(s):
                with open(s) as f:
                    return "".join(l.strip() for l in f if not l.startswith(">"))
            return s
        x, y = clean(read_input(args.seq1)), clean(read_input(args.seq2))
        note = ""

    os.makedirs(args.outdir, exist_ok=True)
    aln = CyclicSemiglobalAligner(args.matrix)
    res = aln.align(x, y, traceback=True)

    print(f"score = {res['score']:.1f}   threshold = {res['threshold']:.0f}   "
          f"is_cp = {res['is_cp']}   breakpoint = {res['breakpoint']}   {note}")

    dotmap(x, y + y, out=os.path.join(args.outdir, "dotmap.png"), window=args.window)
    q = score_profile(aln, m=len(y), out=os.path.join(args.outdir, "score_profile.png"))

    aln_path = os.path.join(args.outdir, "alignment.txt")
    with open(aln_path, "w") as f:
        f.write(f"matrix={args.matrix} score={res['score']:.1f} "
                f"breakpoint(q)={q} crosses_boundary={res.get('crosses_boundary')}\n\n")
        step = 60
        ax_, ay = res.get("aligned_x", ""), res.get("aligned_y", "")
        for k in range(0, max(len(ax_), len(ay)), step):
            f.write("X " + ax_[k:k + step] + "\n")
            f.write("Y " + ay[k:k + step] + "\n\n")
    print(f"Wrote {aln_path}")


if __name__ == "__main__":
    main()
