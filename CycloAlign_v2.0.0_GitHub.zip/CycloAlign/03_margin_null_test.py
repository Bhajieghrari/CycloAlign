#!/usr/bin/env python3
"""
03_margin_null_test.py — Margin-based significance test for CP detection.

Addresses: Reviewer 1 mandatory revision 4 — "construct a test statistic based
on the margin of difference between the maximum score from CP detection search
and the maximum score from normal end-to-end alignment", with a null
distribution built from synthetically homologous pairs of comparable length.

Statistic
---------
    Delta = S_cyclic(X, Y)  -  S_linear(X, Y)

    S_cyclic : best cyclic semi-global score over all permutations (this method)
    S_linear : ordinary end-to-end Needleman-Wunsch score (affine gaps)

A true circular permutation re-uses the SAME residues in a different order, so
the cyclic search can improve on the best linear alignment only when the pair
is genuinely permuted.  Ordinary (non-permuted) homologs have Delta ~= 0, and
unrelated pairs have both scores low — the margin therefore isolates the
permutation signal, which a plain alignment score (or a composition-matched
shuffle Z-score) cannot do.

Null generation
---------------
Synthetic homologues of the tested pair: an ancestor of length matched to the
tested sequences is evolved twice under a uniform point-mutation process
(non-permuted diverged copies, cf. the mutation-simulator approach cited by
the reviewer, doi:10.1093/molbev/msp098).  The divergence rate is chosen so
that the null pairs match the identity of the tested pair, making the null
conservative.  The empirical p-value is

    p = (1 + #{ Delta_null >= Delta_obs }) / (N_null + 1)

Usage
-----
python 03_margin_null_test.py --seq1 X.fasta --seq2 Y.fasta --nulls 200
python 03_margin_null_test.py --demo
"""

from __future__ import annotations

import argparse
import random

from cycloalign_core import AA, CyclicSemiglobalAligner, clean

# --------------------------------------------------------------------------- #


def random_seq(n: int, rng: random.Random) -> str:
    return "".join(rng.choice(AA) for _ in range(n))


def mutate(seq: str, rate: float, rng: random.Random) -> str:
    """Uniform point mutation (substitution only), the core of the null
    generator recommended by Reviewer 1."""
    return "".join(c if rng.random() >= rate else rng.choice(AA) for c in seq)


def identity_estimate(aln: CyclicSemiglobalAligner, x: str, y: str) -> float:
    lx = max(len(x), len(y), 1)
    s = aln.linear_score(x, y)
    return max(0.0, min(1.0, s / (4.0 * lx)))


def divergence_for_identity(target: float) -> float:
    """Crude map from desired identity to per-site mutation rate."""
    return max(0.0, min(0.95, (1.0 - target) * 1.05))


def margin(aln: CyclicSemiglobalAligner, x: str, y: str):
    s_cyc = aln.align(x, y, traceback=False)["score"]
    s_lin = aln.linear_score(x, y)
    return s_cyc, s_lin, s_cyc - s_lin


def run(seq1: str, seq2: str, n_nulls: int, seed: int, matrix: str):
    rng = random.Random(seed)
    aln = CyclicSemiglobalAligner(matrix)

    x, y = clean(seq1), clean(seq2)
    s_cyc, s_lin, d_obs = margin(aln, x, y)
    ident = identity_estimate(aln, x, y)
    rate = divergence_for_identity(ident)

    nulls = []
    anc_len = (len(x) + len(y)) // 2
    for _ in range(n_nulls):
        anc = random_seq(anc_len, rng)
        a = mutate(anc, rate, rng)
        b = mutate(anc, rate, rng)
        nulls.append(margin(aln, a, b)[2])

    n_ge = sum(1 for d in nulls if d >= d_obs)
    p_emp = (1 + n_ge) / (n_nulls + 1)

    mu = sum(nulls) / len(nulls)
    sd = (sum((d - mu) ** 2 for d in nulls) / max(1, len(nulls) - 1)) ** 0.5
    if sd > 0:
        z = (d_obs - mu) / sd
    else:
        z = 0.0 if abs(d_obs - mu) < 1e-9 else float("inf")

    return {
        "s_cyclic": round(s_cyc, 1),
        "s_linear": round(s_lin, 1),
        "margin_observed": round(d_obs, 1),
        "identity_estimated": round(ident, 3),
        "null_mutation_rate": round(rate, 3),
        "null_mean": round(mu, 1),
        "null_sd": round(sd, 1),
        "z_margin": round(z, 2),
        "p_empirical": p_emp,
        "n_nulls": n_nulls,
        "verdict": "CP-specific signal" if (d_obs > 0 and p_emp < 0.05) else "no CP-specific signal",
    }


def demo():
    rng = random.Random(11)
    dom1 = "".join(rng.choice(AA) for _ in range(120))
    dom2 = "".join(rng.choice(AA) for _ in range(120))
    full = dom1 + dom2
    permuted = dom2 + dom1                      # true circular permutation
    x = mutate(full, 0.08, rng)
    y = mutate(permuted, 0.08, rng)
    unrelated = random_seq(240, rng)

    print("Demo 1: true CP pair (>30% identity)")
    print(" ", run(x, y, n_nulls=50, seed=1, matrix="BLOSUM45"))
    print()
    print("Demo 2: ordinary homolog (same domains, NOT permuted)")
    print(" ", run(x, mutate(full, 0.08, rng), n_nulls=50, seed=2, matrix="BLOSUM45"))
    print()
    print("Demo 3: unrelated pair")
    print(" ", run(x, unrelated, n_nulls=50, seed=3, matrix="BLOSUM45"))
    print()
    print("Expected pattern: a large positive margin only for the permuted pair.")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seq1", help="FASTA file or raw sequence, query X")
    ap.add_argument("--seq2", help="FASTA file or raw sequence, target Y")
    ap.add_argument("--nulls", type=int, default=200, help="number of null pairs")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--matrix", default="BLOSUM45")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.demo or not (args.seq1 and args.seq2):
        demo()
        return

    def read_input(s: str) -> str:
        if os.path.exists(s):
            with open(s) as f:
                return "".join(l.strip() for l in f if not l.startswith(">"))
        return s

    res = run(read_input(args.seq1), read_input(args.seq2),
              n_nulls=args.nulls, seed=args.seed, matrix=args.matrix)
    for k, v in res.items():
        print(f"{k:>20}: {v}")


if __name__ == "__main__":
    import os  # placed here to keep module import light
    main()
