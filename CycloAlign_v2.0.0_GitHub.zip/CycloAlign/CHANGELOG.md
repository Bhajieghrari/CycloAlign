# Changelog

All notable changes to CycloAlign are documented here.
Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
versioning: [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0] — 2026-10-28

### Fixed
- **Corrected DP-matrix initialization** (Reviewer 1, Mandatory revision 2):
  only the first row is zero-initialized; the first column is `-inf`
  (except the origin cell). The published v1.0.0 code zeroed both, allowing the
  aligner to discard a leading portion of the query at zero cost — unnecessary
  for CP detection and a source of inflated scores for partially homologous
  pairs. All benchmark numbers in the revised manuscript are regenerated with
  the corrected initialization.

### Changed
- Threshold and gap parameters defined in one place (`cycloalign_core.py`) and
  identical to the revised manuscript tables (Reviewer 1, Suggested revision 1).

### Added
- `01_recompute_statistics.py` — corrected Z-score pipeline (no negative
  Z-scores; range 85.0–130.3) with empirical p-values and multiple-testing
  correction; paired t(29) = 54.31, p = 1.0 × 10⁻³⁰, Cohen's d = 9.91.
- `02_benchmark_cpdb_full.py` — full-CPDB scan (4,169 pairs; 4,166 evaluable)
  with identity-bin stratified reporting; null-calibrated margin-test detection
  98.3% overall, 99.9% above 30% identity.
- `03_margin_null_test.py` — margin statistic Δ = S_cyclic − S_linear with an
  empirical null from identity-matched synthetic homologues.
- `04_runtime_memory_benchmark.py` — scaling exponents (fitted 2.16 time /
  1.99 memory), empirically validating the O(n²) claim.
- `05_visualize_alignment.py` — dot map, score profile, breakpoint annotation.
- `06_hard_negative_benchmark.py` — hardened per-class benchmark
  (unrelated / homologous non-CP / repeat-containing): margin AUC 1.000
  against all classes.
- Executed results of all runs under `outputs/`.

### Deprecated
- The v1.0.0 implementation and all statistics computed with it
  (originally reported t = 48.23, d = 9.05) are superseded; see the
  Statistical Recomputation Note in the response to reviewers.

## [1.0.0] — original publication

- Initial cyclic semi-global alignment implementation (superseded:
  first row and first column both zero-initialized; per-pair Z-scores computed
  against a null estimated from mutually inconsistent summary statistics).
