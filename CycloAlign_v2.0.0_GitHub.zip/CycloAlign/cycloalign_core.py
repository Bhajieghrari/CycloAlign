#!/usr/bin/env python3
"""
cycloalign_core.py — Corrected reference implementation of the Cyclic
Semi-Global Alignment algorithm for protein circular permutation (CP) detection.

This module accompanies the revised manuscript and the response to reviewers.
It implements the algorithm exactly as specified in the revised Methods section,
including the initialization correction requested by Reviewer 1 (Mandatory
revision 2):

    ONLY the first row of the dynamic-programming matrix is initialized to
    zero.  The first column is initialized to -inf (except the origin cell),
    so that every residue of the query sequence X must be consumed by the
    alignment.  Zeroing the first column (as in the previously published
    code) would have allowed the aligner to discard a leading portion of X
    at no cost, which is not required for CP detection and loosens the
    algorithm beyond what is needed: it can inflate scores for pairs that
    share only partial homology and thereby create false positives.

States (Gotoh / affine gaps), following the notation of the manuscript:
    M(i, j)  — best score of an alignment of x_1..x_i with y*_1..y*_j
               ending in a match/mismatch (x_i aligned to y*_j)
    Ix(i, j) — best score ending with x_i aligned to a gap  (gap in Y*)
    Iy(i, j) — best score ending with y*_j aligned to a gap (gap in X)

Recurrences:
    M(i, j)  = max(M, Ix, Iy)(i-1, j-1) + s(x_i, y*_j)
    Ix(i, j) = max(M(i-1, j) - go,  Ix(i-1, j) - ge)
    Iy(i, j) = max(M(i, j-1) - go,  Iy(i, j-1) - ge)

Initialization (corrected):
    M(0, j) = 0        for j = 0..2m     (free start anywhere in Y* —
                                          all breakpoints scored on common ground)
    M(i, 0) = -inf     for i = 1..n      (query prefix may NOT be discarded)
    Ix, Iy    = -inf   on row 0 / column 0

Termination:
    best score  = max over j in [m, 2m] of max(M, Ix, Iy)(n, j)
    A genuine circular permutation of Y occupies Y*[q+1 .. q+m] and therefore
    always terminates in the second copy (j >= m).  The predicted breakpoint
    is q = best_j - m (the number of second-copy residues consumed).

Time complexity  : O(n * 2m) cell updates, each O(1)  ->  O(nm)  (O(n^2) for n ~= m)
Memory complexity: O(n * 2m) with full traceback; O(m) possible for score-only use.
"""

from __future__ import annotations

import numpy as np
from typing import Dict, List, Optional, Tuple

try:  # Biopython is the preferred source of BLOSUM matrices
    from Bio.Align import substitution_matrices

    BIOPYTHON_AVAILABLE = True
except ImportError:  # pragma: no cover - fallback for minimal environments
    BIOPYTHON_AVAILABLE = False

AA = "ACDEFGHIKLMNPQRSTVWY"

# Matrix-specific recommended gap penalties and score thresholds
# (kept in one place so that the manuscript, the README and the code agree —
#  Reviewer 1, Suggested revision 1).
DEFAULT_PARAMS: Dict[str, Dict[str, float]] = {
    "BLOSUM62": {"gap_open": 11.0, "gap_extend": 1.0, "threshold": 500.0},
    "BLOSUM45": {"gap_open": 15.0, "gap_extend": 2.0, "threshold": 1000.0},
    "BLOSUM30": {"gap_open": 20.0, "gap_extend": 3.0, "threshold": 2000.0},
}


def _fallback_matrix(match: float = 4.0, conservative: float = 1.0, mismatch: float = -1.0):
    """Very small substitution matrix used only when Biopython is unavailable."""
    groups = ["AG", "ST", "DE", "NQ", "KR", "ILV", "FYW", "CM"]
    mat = np.full((20, 20), mismatch, dtype=np.float64)
    idx = {a: k for k, a in enumerate(AA)}
    for a in AA:
        mat[idx[a], idx[a]] = match
    for g in groups:
        for a1 in g:
            for a2 in g:
                mat[idx[a1], idx[a2]] = conservative
    return mat


def load_matrix(name: str):
    """Return (matrix as 20x20 numpy array, alphabet index). Biopython if present."""
    if BIOPYTHON_AVAILABLE:
        try:
            bm = substitution_matrices.load(name)
            mat = np.array([[bm[a, b] for b in AA] for a in AA], dtype=np.float64)
            return mat, {a: k for k, a in enumerate(AA)}
        except Exception:
            pass
    return _fallback_matrix(), {a: k for k, a in enumerate(AA)}


def clean(seq: str) -> str:
    return "".join(c for c in seq.upper() if c in AA)


class CyclicSemiglobalAligner:
    """Corrected cyclic semi-global aligner (see module docstring)."""

    def __init__(self, matrix_name: str = "BLOSUM45",
                 gap_open: Optional[float] = None,
                 gap_extend: Optional[float] = None):
        p = DEFAULT_PARAMS.get(matrix_name, DEFAULT_PARAMS["BLOSUM45"])
        self.matrix_name = matrix_name
        self.gap_open = float(gap_open if gap_open is not None else p["gap_open"])
        self.gap_extend = float(gap_extend if gap_extend is not None else p["gap_extend"])
        self.threshold = float(p.get("threshold", 1000.0))
        self.mat, self.idx = load_matrix(matrix_name)
        self.last_profile: Optional[np.ndarray] = None

    # ------------------------------------------------------------------ #
    def align(self, seq_x: str, seq_y: str, traceback: bool = True) -> Dict:
        """Cyclic semi-global alignment of X against Y* = Y + Y (duplicated)."""
        x = clean(seq_x)
        y = clean(seq_y)
        if not x or not y:
            raise ValueError("sequences must contain canonical amino acids")
        n, m = len(x), len(y)
        yy = y + y
        L = 2 * m
        go, ge = self.gap_open, self.gap_extend

        NEG = -np.inf
        M = np.full((n + 1, L + 1), NEG, dtype=np.float64)
        Ix = np.full((n + 1, L + 1), NEG, dtype=np.float64)  # gap in Y*
        Iy = np.full((n + 1, L + 1), NEG, dtype=np.float64)  # gap in X

        # --- corrected initialization (Reviewer 1, mandatory revision 2) ---
        # First row zero: alignment may start at ANY position of Y* at no
        # cost, so every candidate breakpoint of Y is scored on common ground.
        M[0, :] = 0.0
        # First column NOT zero (corrected): the leading residues of the query
        # X must be aligned; they may no longer be discarded for free.
        # M[i, 0] stays -inf for i >= 1, which forces full consumption of X.

        # DP fill — O((n+1) x (2m+1)) cells, O(1) work each.
        for i in range(1, n + 1):
            xi = self.idx[x[i - 1]]
            row_m = self.mat[xi]
            for j in range(1, L + 1):
                sc = row_m[self.idx[yy[j - 1]]]
                M[i, j] = max(M[i - 1, j - 1], Ix[i - 1, j - 1], Iy[i - 1, j - 1]) + sc
                Ix[i, j] = max(M[i - 1, j] - go, Ix[i - 1, j] - ge)   # consume x_i
                Iy[i, j] = max(M[i, j - 1] - go, Iy[i, j - 1] - ge)   # consume y*_j

        # Termination: best score in the bottom row, second copy only.
        best_score, best_j = NEG, m
        bottom = np.maximum(np.maximum(M[n, :], Ix[n, :]), Iy[n, :])
        for j in range(m, L + 1):
            if bottom[j] > best_score:
                best_score, best_j = bottom[j], j
        self.last_profile = bottom.copy()

        out = {
            "score": float(best_score),
            "end_j": int(best_j),
            "breakpoint": int(best_j - m),  # residues taken from the second copy
            "is_cp": bool(best_score >= self.threshold),
            "threshold": self.threshold,
        }

        if traceback and np.isfinite(best_score):
            out.update(self._traceback(M, Ix, Iy, x, yy, best_j))
        return out

    # ------------------------------------------------------------------ #
    def _traceback(self, M, Ix, Iy, x, yy, best_j) -> Dict:
        """State-aware traceback; reports the alignment strings and records the
        region of the duplication boundary j = m touched by the path."""
        n, L = len(x), len(yy)
        i, j = n, best_j
        state = max(
            [("M", M[i, j]), ("Ix", Ix[i, j]), ("Iy", Iy[i, j])], key=lambda t: t[1]
        )[0]
        xal, yal = [], []
        min_j_visited = j
        path: List[Tuple[int, int]] = []
        while i > 0 and j > 0:
            path.append((i, j))
            if state == "M":
                xal.append(x[i - 1])
                yal.append(yy[j - 1])
                prev = max(
                    [("M", M[i - 1, j - 1]), ("Ix", Ix[i - 1, j - 1]), ("Iy", Iy[i - 1, j - 1])],
                    key=lambda t: t[1],
                )
                i, j = i - 1, j - 1
                state = prev[0]
            elif state == "Ix":  # x_i aligned to a gap in Y*
                xal.append(x[i - 1])
                yal.append("-")
                state = "M" if Ix[i, j] == M[i - 1, j] - self.gap_open else "Ix"
                i -= 1
            else:  # Iy — y*_j aligned to a gap in X
                xal.append("-")
                yal.append(yy[j - 1])
                state = "M" if Iy[i, j] == M[i, j - 1] - self.gap_open else "Iy"
                j -= 1
            if j < min_j_visited:
                min_j_visited = j
        path.append((i, j))
        xal.reverse()
        yal.reverse()
        return {
            "aligned_x": "".join(xal),
            "aligned_y": "".join(yal),
            "path_len": len(path),
            "min_j_visited": int(min_j_visited),
            "crosses_boundary": bool(min_j_visited < L // 2),
        }

    # ------------------------------------------------------------------ #
    def linear_score(self, seq_x: str, seq_y: str) -> float:
        """Ordinary end-to-end (Needleman-Wunsch, affine gaps) alignment score.
        Used by the margin-based statistic of Reviewer 1, mandatory revision 4:
        Delta = S_cyclic(best permutation) - S_linear."""
        x, y = clean(seq_x), clean(seq_y)
        n, m = len(x), len(y)
        go, ge = self.gap_open, self.gap_extend
        NEG = -np.inf
        prevM = np.full(m + 1, NEG)
        prevX = np.full(m + 1, NEG)
        prevY = np.full(m + 1, NEG)
        # end-to-end global alignment: leading gaps free in both directions
        prevM[0] = 0.0
        prevY[0] = 0.0
        for j in range(1, m + 1):
            prevY[j] = 0.0
        for i in range(1, n + 1):
            curM = np.full(m + 1, NEG)
            curX = np.full(m + 1, NEG)
            curY = np.full(m + 1, NEG)
            xi = self.idx[x[i - 1]]
            row = self.mat[xi]
            curX[0] = max(prevM[0] - go, prevX[0] - ge)
            for j in range(1, m + 1):
                sc = row[self.idx[y[j - 1]]]
                curM[j] = max(prevM[j - 1], prevX[j - 1], prevY[j - 1]) + sc
                curX[j] = max(prevM[j] - go, prevX[j] - ge)
                curY[j] = max(curM[j - 1] - go, curY[j - 1] - ge)
            prevM, prevX, prevY = curM, curX, curY
        return float(max(prevM[m], prevX[m], prevY[m]))


def pairwise_identity(a: str, b: str) -> float:
    """Rough percent-identity proxy from a normalized global score.
    (The full benchmark script uses this only for stratified reporting;
    users with Biopython may substitute pairwise2/Align identity directly.)"""
    aln = CyclicSemiglobalAligner("BLOSUM45")
    s = aln.linear_score(a, b)
    return max(0.0, min(100.0, 100.0 * s / (4.0 * min(len(a), len(b)))))
