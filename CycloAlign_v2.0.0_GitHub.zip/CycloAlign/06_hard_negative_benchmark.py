#!/usr/bin/env python3
"""
06_hard_negative_benchmark.py — Hardened synthetic benchmark with per-class
negative controls (Reviewer 3, major comment 5), per-class AUC for three
statistics (raw score, length-normalized score, margin), breakpoint accuracy,
and threshold sensitivity (Reviewer 3, major comment 6).

Classes (N pairs each, length L, seed fixed):
  cp        : synthetically permuted homologues (positives; breakpoint L//2)
  unrelated : independent random sequences
  hom_ncp   : same ancestor, same mutation process, ORIGINAL order (non-CP)
  repeat    : target = duplicated domain (D+D), query = one diverged copy (trap)

Statistics per pair: raw score S_cyc, normalized score S_cyc/|X|, margin
Delta = S_cyc - S_lin. Reported: per-class AUC of each statistic, breakpoint
agreement within +/-10 for positives, detection/FPR per threshold.

Usage:
  python 06_hard_negative_benchmark.py --pairs-per-class 150 --length 200 \
         --workers 2 --output hardneg_results [--budget 540]
The run is checkpointed (per_pair.csv) and resumes automatically.
"""
from __future__ import annotations

import argparse, csv, json, os, random, statistics, time
from concurrent.futures import ProcessPoolExecutor

from cycloalign_core import AA, CyclicSemiglobalAligner

def _mutate(seq: str, rate: float, rng: random.Random) -> str:
    return "".join(c if rng.random() >= rate else rng.choice(AA) for c in seq)

def make_classes(n_per_class: int, L: int, seed: int):
    rng = random.Random(seed)
    classes = {"cp": [], "unrelated": [], "hom_ncp": [], "repeat": []}
    truth = []
    for _ in range(n_per_class):
        rate = rng.uniform(0.05, 0.45)
        anc = "".join(rng.choice(AA) for _ in range(L))
        x = _mutate(anc, rate, rng)
        y = _mutate(anc[L // 2:] + anc[:L // 2], rate, rng)
        classes["cp"].append((x, y)); truth.append(L // 2)
    for _ in range(n_per_class):
        classes["unrelated"].append(("".join(rng.choice(AA) for _ in range(L)),
                                     "".join(rng.choice(AA) for _ in range(L))))
    for _ in range(n_per_class):
        rate = rng.uniform(0.05, 0.45)
        anc = "".join(rng.choice(AA) for _ in range(L))
        classes["hom_ncp"].append((_mutate(anc, rate, rng), _mutate(anc, rate, rng)))
    for _ in range(n_per_class):
        rate = rng.uniform(0.05, 0.45)
        dom = "".join(rng.choice(AA) for _ in range(L // 2))
        q = _mutate(dom, rate, rng)                    # query = single domain copy
        t = _mutate(dom, rate, rng) + _mutate(dom, rate, rng)  # target = D + D
        classes["repeat"].append((q, t))
    return classes, truth

_ALN = None
def _init(matrix):
    global _ALN
    _ALN = CyclicSemiglobalAligner(matrix)

def eval_pair(job):
    cls, idx, x, y, bp = job
    res = _ALN.align(x, y, traceback=False)
    s_lin = _ALN.linear_score(x, y)
    score = res["score"]
    return {
        "class": cls, "idx": idx,
        "score": round(score, 1),
        "norm_score": round(score / max(len(x), 1), 3),
        "margin": round(score - s_lin, 1),
        "pred_bp": res["breakpoint"] if cls == "cp" else "",
        "true_bp": bp if cls == "cp" else "",
        "identity_pct": "",  # filled below (aligned columns not needed here)
    }

def auc(pos, neg):
    """Rank-based AUC (Mann-Whitney). Higher statistic = more positive-like."""
    if not pos or not neg:
        return None
    wins = ties = 0
    for p in pos:
        for q in neg:
            if p > q: wins += 1
            elif p == q: ties += 1
    return (wins + 0.5 * ties) / (len(pos) * len(neg))

def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pairs-per-class", type=int, default=150)
    ap.add_argument("--length", type=int, default=200)
    ap.add_argument("--matrix", default="BLOSUM45")
    ap.add_argument("--seed", type=int, default=20260)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--budget", type=float, default=0.0, help="seconds; checkpoint-resume")
    ap.add_argument("--output", default="hardneg_results")
    args = ap.parse_args()

    os.makedirs(args.output, exist_ok=True)
    csv_path = os.path.join(args.output, "per_pair.csv")

    classes, truth = make_classes(args.pairs_per_class, args.length, args.seed)
    jobs = []
    for cls, pairs in classes.items():
        for i, (x, y) in enumerate(pairs):
            bp = truth[i] if cls == "cp" else ""
            jobs.append((cls, i, x, y, bp))

    done = set()
    if os.path.exists(csv_path):
        with open(csv_path) as f:
            for row in csv.DictReader(f):
                done.add((row["class"], row["idx"]))
    todo = [j for j in jobs if (j[0], str(j[1])) not in done]
    print(f"total: {len(jobs)}, done: {len(done)}, remaining: {len(todo)}", flush=True)

    if todo:
        fieldnames = ["class", "idx", "score", "norm_score", "margin", "pred_bp", "true_bp", "identity_pct"]
        new_file = not os.path.exists(csv_path) or os.path.getsize(csv_path) == 0
        t0 = time.time()
        k = 0
        with open(csv_path, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            if new_file:
                w.writeheader()
            with ProcessPoolExecutor(max_workers=args.workers,
                                     initializer=_init, initargs=(args.matrix,)) as ex:
                B = 40
                for s in range(0, len(todo), B):
                    if args.budget and time.time() - t0 > args.budget:
                        print(f"budget exhausted at {k}", flush=True)
                        break
                    batch = todo[s:s + B]
                    try:
                        for res in ex.map(eval_pair, batch, chunksize=4):
                            w.writerow(res); k += 1
                        f.flush()
                        print(f"progress {len(done) + k}/{len(jobs)} "
                              f"({time.time() - t0:.0f} s)", flush=True)
                    except Exception as e:
                        print(f"batch error: {e!r}", flush=True)
                        break
        done_n = len(done) + k
    else:
        done_n = len(done)

    rows = []
    if os.path.exists(csv_path):
        with open(csv_path) as f:
            rows = list(csv.DictReader(f))
    if len(rows) < len(jobs):
        print(f"checkpointed {len(rows)}/{len(jobs)} — rerun to continue", flush=True)
        return

    # ---------------- final analysis ----------------
    by = {}
    for r in rows:
        by.setdefault(r["class"], []).append(r)
    res = {"n_per_class": {c: len(v) for c, v in by.items()}, "L": args.length,
           "matrix": args.matrix, "seed": args.seed}

    pos_margin = [float(r["margin"]) for r in by["cp"]]
    pos_score = [float(r["score"]) for r in by["cp"]]
    pos_norm = [float(r["norm_score"]) for r in by["cp"]]

    res["class_stats"] = {}
    for cls in ("cp", "unrelated", "hom_ncp", "repeat"):
        rs = by[cls]
        res["class_stats"][cls] = {
            "score_median": statistics.median(float(r["score"]) for r in rs),
            "norm_median": statistics.median(float(r["norm_score"]) for r in rs),
            "margin_median": statistics.median(float(r["margin"]) for r in rs),
            "margin_max": max(float(r["margin"]) for r in rs),
            "margin_min": min(float(r["margin"]) for r in rs),
        }

    res["auc"] = {}
    for cls in ("unrelated", "hom_ncp", "repeat"):
        neg_m = [float(r["margin"]) for r in by[cls]]
        neg_s = [float(r["score"]) for r in by[cls]]
        neg_n = [float(r["norm_score"]) for r in by[cls]]
        res["auc"][cls] = {
            "score_vs_cp": auc(pos_score, neg_s),
            "norm_vs_cp": auc(pos_norm, neg_n),
            "margin_vs_cp": auc(pos_margin, neg_m),
        }

    # breakpoint accuracy on positives
    errs = [abs(int(r["pred_bp"]) - int(r["true_bp"])) for r in by["cp"]
            if r["pred_bp"] != "" and r["true_bp"] != ""]
    res["breakpoint"] = {
        "within10": sum(1 for e in errs if e <= 10), "n": len(errs),
        "median_err": statistics.median(errs) if errs else None,
    }

    # threshold sensitivity (raw score): detection per identity? — here per class FPR/TPR
    res["thresholds"] = {}
    for th in (250, 500, 750, 1000, 1500, 2000):
        tpr = sum(1 for r in by["cp"] if float(r["score"]) >= th) / len(by["cp"])
        fpr = {cls: sum(1 for r in by[cls] if float(r["score"]) >= th) / len(by[cls])
               for cls in ("unrelated", "hom_ncp", "repeat")}
        res["thresholds"][th] = {"TPR": round(tpr, 3), **{f"FPR_{c}": round(v, 3) for c, v in fpr.items()}}

    # margin-rule operating point (Delta > margin_max of hom_ncp)
    null_max = res["class_stats"]["hom_ncp"]["margin_max"]
    res["margin_rule"] = {
        "null_max": null_max,
        "TPR_cp": round(sum(1 for r in by["cp"] if float(r["margin"]) > null_max) / len(by["cp"]), 3),
        "FPR_unrelated": round(sum(1 for r in by["unrelated"] if float(r["margin"]) > null_max) / len(by["unrelated"]), 3),
        "FPR_hom_ncp": round(sum(1 for r in by["hom_ncp"] if float(r["margin"]) > null_max) / len(by["hom_ncp"]), 3),
        "FPR_repeat": round(sum(1 for r in by["repeat"] if float(r["margin"]) > null_max) / len(by["repeat"]), 3),
    }

    with open(os.path.join(args.output, "summary.json"), "w") as f:
        json.dump(res, f, indent=2)
    print(json.dumps(res, indent=2))
    print("\nWrote", os.path.join(args.output, "summary.json"))

if __name__ == "__main__":
    main()
