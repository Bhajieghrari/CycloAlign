#!/usr/bin/env python3
"""
04_runtime_memory_benchmark.py — Empirical time and memory scaling of the
cyclic semi-global aligner.

Addresses: Reviewer 3 major comment 8 ("the manuscript lacks convincing
empirical runtime and memory benchmarks ... supported by experiments across
different protein lengths"); supports the O(n^2) claim with measured data
instead of theory alone (Reviewer 3 minor comment on notation).

For each length n (doubled from --min-len to --max-len) the script aligns R
random sequence pairs, records wall-clock time (best of R) and peak memory
(tracemalloc), then fits

    log(t) = slope * log(n) + c

The fitted slope is the empirical complexity exponent; the O(n^2) prediction
corresponds to slope ~= 2.

Usage
-----
python 04_runtime_memory_benchmark.py --min-len 100 --max-len 1600 --reps 3
python 04_runtime_memory_benchmark.py --plot            # writes scaling.png
"""

from __future__ import annotations

import argparse
import math
import random
import time
import tracemalloc

from cycloalign_core import AA, CyclicSemiglobalAligner


def time_one(aln: CyclicSemiglobalAligner, x: str, y: str, reps: int):
    best = math.inf
    tracemalloc.start()
    for _ in range(reps):
        t0 = time.perf_counter()
        aln.align(x, y, traceback=False)
        best = min(best, time.perf_counter() - t0)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return best, peak / 1e6  # seconds, MB


def run_lengths(lengths, reps, seed, matrix):
    rng = random.Random(seed)
    aln = CyclicSemiglobalAligner(matrix)
    rows = []
    for n in lengths:
        x = "".join(rng.choice(AA) for _ in range(n))
        y = "".join(rng.choice(AA) for _ in range(n))
        t, mem = time_one(aln, x, y, reps)
        rows.append({"n": n, "seconds": t, "peak_mb": mem})
        print(f"  n = {n:>5}   t = {t:8.3f} s   peak mem = {mem:7.1f} MB")
    return rows


def fit_slope(rows):
    xs = [math.log(r["n"]) for r in rows]
    ys = [math.log(r["seconds"]) for r in rows]
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
    return slope


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--min-len", type=int, default=100)
    ap.add_argument("--max-len", type=int, default=1600)
    ap.add_argument("--reps", type=int, default=3)
    ap.add_argument("--matrix", default="BLOSUM45")
    ap.add_argument("--seed", type=int, default=2024)
    ap.add_argument("--plot", action="store_true", help="save a log-log figure (scaling.png)")
    args = ap.parse_args()

    lengths, n = [], args.min_len
    while n <= args.max_len:
        lengths.append(n)
        n *= 2

    print(f"Empirical scaling benchmark ({args.matrix}, traceback disabled):")
    rows = run_lengths(lengths, args.reps, args.seed, args.matrix)
    slope = fit_slope(rows)
    print(f"\nFitted time exponent  log(t) ~ {slope:.2f} * log(n)   "
          f"(O(n^2) prediction: 2.00)")
    mem_slope = None
    if rows[0]["peak_mb"] > 0:
        xs = [math.log(r["n"]) for r in rows]
        ys = [math.log(r["peak_mb"]) for r in rows]
        k = len(xs)
        mx, my = sum(xs) / k, sum(ys) / k
        mem_slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
        print(f"Fitted memory exponent log(m) ~ {mem_slope:.2f} * log(n) (O(n^2) prediction: 2.00)")

    if args.plot:
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt

            ns = [r["n"] for r in rows]
            ts = [r["seconds"] for r in rows]
            fig, ax = plt.subplots(figsize=(6, 4.2), constrained_layout=True)
            ax.loglog(ns, ts, "o-", label="measured wall time")
            ref = [ts[0] * (v / ns[0]) ** 2 for v in ns]
            ax.loglog(ns, ref, "--", label="O(n$^2$) reference")
            ax.set_xlabel("sequence length n (aa)")
            ax.set_ylabel("time per pair (s)")
            ax.set_title(f"Empirical scaling: exponent = {slope:.2f}")
            ax.legend()
            fig.savefig("scaling.png", dpi=200)
            print("Wrote scaling.png")
        except ImportError:
            print("matplotlib not available — skipping figure")

    print("\nReport these measured exponents (not only the theoretical argument) "
          "in the revised manuscript, Results > Runtime and memory benchmarks.")


if __name__ == "__main__":
    main()
