#!/usr/bin/env python3
"""
02_benchmark_cpdb_full.py — Evaluate CP detection on the complete CPDB
(about 4,169 structurally validated pairs), stratified by sequence identity.

Addresses: Reviewer 1 mandatory revision 3 (benchmark against the ~4,000 known
CP pairs in CPDB); Reviewer 3 major comments 7 and 9 (head-to-head evaluation,
documented datasets); Reviewer 3 minor comment on released benchmark data.

Input formats
-------------
pairs.tsv  : tab-separated: pdb_id_1  pdb_id_2  annotated_breakpoint(optional)
fasta_dir/ : one FASTA file per PDB/chain ID, named <id>.fasta

If the real CPDB dump is not yet downloaded, the script falls back to a small
synthetic self-test so the pipeline can be validated end to end.

Usage
-----
python 02_benchmark_cpdb_full.py --pairs cpdb_pairs.tsv --fasta-dir fasta/ \
       --matrix BLOSUM45 --identity-bins 20,30,40,50 --workers 8 \
       --output cpdb_results/

Output
------
cpdb_results/per_pair.csv      pair id, identity, score, prediction, breakpoint error
cpdb_results/stratified.txt    detection rate per identity bin + overall summary
"""

from __future__ import annotations

import argparse
import csv
import os
import random
from concurrent.futures import ProcessPoolExecutor

from cycloalign_core import (AA, CyclicSemiglobalAligner, DEFAULT_PARAMS,
                             clean, load_matrix)

# --------------------------------------------------------------------------- #
# Synthetic fallback data (only used when the real CPDB dump is not supplied)
# --------------------------------------------------------------------------- #

def _mutate(seq: str, rate: float, rng: random.Random) -> str:
    out = []
    for c in seq:
        r = rng.random()
        if r < rate:
            out.append(rng.choice(AA))
        else:
            out.append(c)
    return "".join(out)


def make_selftest(n_pairs: int = 40, length: int = 300, seed: int = 7):
    """High-identity CP pairs (positives) plus unrelated pairs (controls)."""
    rng = random.Random(seed)
    base = "".join(rng.choice(AA) for _ in range(length))
    pairs, labels, bps = [], [], []
    for k in range(n_pairs):
        dom_a = base[: length // 2]
        dom_b = base[length // 2:]
        flip = rng.random() < 0.5
        y = dom_b + dom_a if flip else base              # permuted copy
        y = _mutate(y, 0.10, rng)                        # ~90% identity backbone
        x = _mutate(base, 0.10, rng)
        pairs.append((x, y))
        labels.append(1)
        bps.append(length // 2 if flip else 0)
    for k in range(n_pairs // 4):
        x = "".join(rng.choice(AA) for _ in range(length))
        y = "".join(rng.choice(AA) for _ in range(length))
        pairs.append((x, y))
        labels.append(0)
        bps.append(-1)
    return pairs, labels, bps


def load_pairs(path: str):
    pairs, bps = [], []
    with open(path) as f:
        for line in f:
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 2:
                continue
            bp = int(parts[2]) if len(parts) > 2 and parts[2].strip().lstrip("-").isdigit() else -1
            pairs.append((parts[0], parts[1], bp))
    return pairs


def load_fasta_dir(d: str):
    seqs = {}
    for fn in os.listdir(d):
        if not fn.endswith((".fasta", ".fa")):
            continue
        with open(os.path.join(d, fn)) as f:
            seq = "".join(l.strip() for l in f if not l.startswith(">"))
        seqs[os.path.splitext(fn)[0]] = seq
    return seqs


def eval_one(job):
    idx, x, y, bp, matrix = job
    det = CyclicSemiglobalAligner(matrix)
    res = det.align(x, y, traceback=False)
    s_lin = det.linear_score(x, y)
    margin = res["score"] - s_lin
    from cycloalign_core import pairwise_identity
    ident = pairwise_identity(x, y)
    bp_err = ""
    if bp is not None and bp >= 0 and res["score"] >= det.threshold:
        bp_err = abs(res["breakpoint"] - bp)
    return {
        "pair": idx,
        "identity_pct": round(ident, 1),
        "score": round(res["score"], 1),
        "linear_score": round(s_lin, 1),
        "margin": round(margin, 1),
        "detected_threshold": res["score"] >= det.threshold,
        "detected_margin": margin > 0,
        "predicted_breakpoint": res["breakpoint"],
        "annotated_breakpoint": bp,
        "breakpoint_error": bp_err,
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pairs", help="TSV: id1 <TAB> id2 [TAB] breakpoint")
    ap.add_argument("--fasta-dir", help="directory with <id>.fasta files")
    ap.add_argument("--matrix", default="BLOSUM45", choices=list(DEFAULT_PARAMS))
    ap.add_argument("--identity-bins", default="20,30,40,50")
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--limit", type=int, default=0, help="evaluate only the first N pairs")
    ap.add_argument("--selftest", action="store_true", help="run the built-in synthetic self-test")
    ap.add_argument("--output", default="cpdb_results")
    args = ap.parse_args()

    os.makedirs(args.output, exist_ok=True)

    if args.pairs and args.fasta_dir:
        seqs = load_fasta_dir(args.fasta_dir)
        raw = load_pairs(args.pairs)
        jobs = []
        for i, (a, b, bp) in enumerate(raw):
            if a not in seqs or b not in seqs:
                continue
            jobs.append((f"{a}|{b}", seqs[a], seqs[b], bp, args.matrix))
        src = args.pairs
    else:
        pairs, labels, bps = make_selftest()
        jobs = [(f"selftest_{i}_{lab}", x, y, bp, args.matrix)
                for i, ((x, y), lab, bp) in enumerate(zip(pairs, labels, bps))]
        src = "built-in synthetic self-test (no CPDB dump supplied)"

    if args.limit:
        jobs = jobs[: args.limit]

    print(f"Source: {src}")
    print(f"Evaluating {len(jobs)} pairs with {args.matrix} "
          f"(gap {DEFAULT_PARAMS[args.matrix]['gap_open']:.0f}/{DEFAULT_PARAMS[args.matrix]['gap_extend']:.0f}, "
          f"threshold {DEFAULT_PARAMS[args.matrix]['threshold']:.0f}) ...")

    if args.workers > 1:
        with ProcessPoolExecutor(max_workers=args.workers) as ex:
            results = list(ex.map(eval_one, jobs))
    else:
        results = [eval_one(j) for j in jobs]

    per_pair_csv = os.path.join(args.output, "per_pair.csv")
    with open(per_pair_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        w.writeheader()
        w.writerows(results)

    bins = [float(b) for b in args.identity_bins.split(",")]
    lines = ["", "Detection rate stratified by sequence identity:", "",
             "(threshold-based: score >= %.0f; margin-based: S_cyclic - S_linear > 0)"
             % DEFAULT_PARAMS[args.matrix]["threshold"]]
    edges = [0.0] + bins + [100.0]
    for lo, hi in zip(edges[:-1], edges[1:]):
        grp = [r for r in results if lo <= r["identity_pct"] < hi]
        if not grp:
            continue
        det_t = sum(r["detected_threshold"] for r in grp)
        det_m = sum(r["detected_margin"] for r in grp)
        bp_ok = sum(1 for r in grp if r["breakpoint_error"] != "" and r["breakpoint_error"] <= 10)
        lines.append(f"  identity {lo:>5.1f}-{hi:<5.1f}% : threshold {det_t:>4}/{len(grp):<4} "
                     f"({100.0 * det_t / len(grp):5.1f}%) | margin {det_m:>4}/{len(grp):<4} "
                     f"({100.0 * det_m / len(grp):5.1f}%) | breakpoints within 10 aa: {bp_ok}")
    n_det_t = sum(r["detected_threshold"] for r in results)
    n_det_m = sum(r["detected_margin"] for r in results)
    lines += ["",
              f"Overall: threshold {n_det_t}/{len(results)} ({100.0 * n_det_t / len(results):.1f}%), "
              f"margin {n_det_m}/{len(results)} ({100.0 * n_det_m / len(results):.1f}%)",
              "Per-pair results written to " + per_pair_csv,
              "",
              "Reminder (response letter, R3-M3): CPDB contains no validated negative pairs;",
              "report detection recall per identity bin, not specificity or MCC."]
    report = os.path.join(args.output, "stratified.txt")
    with open(report, "w") as f:
        f.write("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
