# CycloAlign

**Cyclic semi-global alignment for sequence-based detection of protein circular permutations.**

Reference implementation and benchmark suite accompanying the revised manuscript
*"A Cyclic Semi-Global Alignment Dynamic Programming Algorithm for Sequence-Based
Detection of Protein Circular Permutations"* (B. Hajieghrari & M. Kamalizadeh).

CycloAlign aligns a query protein X against a rotated/reordered subject Y* with an
affine-gap semi-global dynamic program in which **every residue of the query must be
consumed**. The **margin statistic** Δ = S_cyclic − S_linear (the same alignment with
Y* replaced by the unpermuted Y) separates true circular permutations from ordinary
homology, and is calibrated against identity-matched synthetic-homologue nulls.

> **What is new in v2.0.0** — the previously published code zero-initialized both the
> first row *and* the first column of the DP matrix, letting the aligner discard a
> leading portion of the query at zero cost. v2.0.0 corrects the initialization
> (**first row = 0, first column = −inf**), centralizes threshold/gap parameters, and
> adds the full benchmark suite. All numbers in the revised manuscript were
> regenerated with the corrected initialization. See [CHANGELOG.md](CHANGELOG.md).

## Repository layout

| Path | Purpose |
|------|---------|
| `cycloalign_core.py` | Corrected reference implementation (Gotoh states M/Ix/Iy; cyclic rotation enumeration; `pairwise_identity`) |
| `01_recompute_statistics.py` | Z-scores, empirical p-values, multiple-testing correction from per-pair scores (`--demo` reproduces the Recomputation Note) |
| `02_benchmark_cpdb_full.py` | Full-CPDB scan (4,169 pairs): per-pair scores, margins, aligned identity, timing, 10-point identity bins (`--selftest` without data) |
| `03_margin_null_test.py` | Margin Δ with an empirical null from identity-matched synthetic homologues (mutation-based generator) |
| `04_runtime_memory_benchmark.py` | Wall-clock / peak-memory scaling with fitted log-log exponents (empirically validates O(n²)) |
| `05_visualize_alignment.py` | Dot map X vs Y*, bottom-row score profile with breakpoint annotation, textual alignment |
| `06_hard_negative_benchmark.py` | Hardened per-class benchmark (unrelated / homologous non-CP / repeat-containing): per-class AUC, breakpoint accuracy, threshold sensitivity; checkpoint-resumable |
| `outputs/` | Executed results released with the revision (see table below) |
| `.github/workflows/ci.yml` | CI: runs every self-contained demo/self-test on Python 3.10–3.12 |

## Installation

```bash
git clone https://github.com/Bhajieghrari/CycloAlign.git
cd CycloAlign
pip install -r requirements.txt        # numpy, matplotlib, biopython
# or, to install the core module as a package:
pip install .
```

Python ≥ 3.10. Biopython is optional but recommended (standard BLOSUM matrices);
the scripts fall back to embedded matrices otherwise.

## Quick start

```bash
# 1. Reproduce the statistical recomputation (Statistical Recomputation Note)
python 01_recompute_statistics.py --demo

# 2. Margin null test, self-contained demo
python 03_margin_null_test.py --demo

# 3. Runtime / memory scaling (fitted exponents ~2.16 time / ~1.99 memory)
python 04_runtime_memory_benchmark.py --max-len 800 --plot

# 4. Alignment visualization (dot map + score profile + breakpoint)
python 05_visualize_alignment.py --demo

# 5. Hardened per-class benchmark
python 06_hard_negative_benchmark.py --pairs-per-class 150 --length 200 --workers 2

# 6. Full CPDB scan — first self-test, then with the real data dump
python 02_benchmark_cpdb_full.py --selftest
python 02_benchmark_cpdb_full.py --pairs outputs/cpdb_pairs.tsv --fasta-dir fasta/ --workers 8
```

The CPDB pair list (4,169 non-redundant pairs over 2,238 PDB chains, as released
with plmCP, Hu et al. 2024) ships in `outputs/cpdb_pairs.tsv`; download the
corresponding per-chain FASTA files into `fasta/` to rerun the full scan. Using the
same pair list and sequences as plmCP makes the head-to-head comparison exact.
Three pairs involving two all-X chains (1qtjA, 2pgkA) are not evaluable by any
sequence method; the scan excludes and logs them.

## Executed results (`outputs/`)

| File | Content |
|------|---------|
| `cpdb_pairs.tsv` | CPDB release pair list (4,169 pairs, PDB chain IDs) |
| `cpdb_full_per_pair.csv` | Per-pair full-scan results: aligned identity, cyclic/linear scores, margin, flags, predicted breakpoint, runtime (4,166 rows) |
| `cpdb_full_summary.json` | Stratified summary: per-bin medians/counts, overall detection rates, runtime statistics |
| `hardneg_per_pair.csv`, `hardneg_summary.json` | Hardened benchmark (150 pairs/class, length 200): per-class AUC, breakpoint accuracy, threshold sensitivity |
| `margin_calibration_length173.json` | Negative-control calibration at CPDB median length (400 homologous non-CP controls, max Δ = 7) |
| `validation30_margins_per_pair.csv`, `validation30_margins_summary.json` | Per-pair margin nulls for the 30 validation pairs (Δ, null mean/SD, z, empirical p, verdict) |
| `runtime_scaling.json` | Runtime/memory scaling measurements and fitted exponents |

Headline numbers (corrected initialization, BLOSUM45 15/2): full-CPDB margin-test
detection **98.3%** overall, **99.9%** above 30% identity; margin AUC **1.000**
against all hard-negative classes; paired t(29) = 54.31, p = 1.0 × 10⁻³⁰,
Cohen's d = 9.91 for the corrected vs published implementation.

## Citation

If you use CycloAlign, please cite the manuscript and the software archive:

```bibtex
@software{CycloAlign_2_0_0,
  author    = {Hajieghrari, Behzad and Kamalizadeh, Mojahed},
  title     = {CycloAlign: cyclic semi-global alignment for sequence-based
               detection of protein circular permutations},
  version   = {2.0.0},
  doi       = {10.5281/zenodo.XXXXXXX},  % assigned by Zenodo on first release
  url       = {https://github.com/Bhajieghrari/CycloAlign}
}
```

The DOI badge and `CITATION.cff` are finalized once the repository is archived on
Zenodo (the DOI is minted automatically for the tagged release `v2.0.0`).

## License

MIT — see [LICENSE](LICENSE).
